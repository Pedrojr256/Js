const botaoEncomenda = document.querySelector(".botao-encomenda");
const orientaçõesEncomenda = document.querySelector(".orientações-encomenda")

botaoEncomenda.addEventListener("click",function  () {
 orientaçõesEncomenda.classList.toggle("oculto");
 if (orientaçõesEncomenda.classList.contains("oculto")) {
    botaoEncomenda.textContent ="Solicitar encomenda";
 } else {
    botaoEncomenda.textContent = "Ocultar oritações";
 }
});